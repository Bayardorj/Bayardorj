<?php
$num = array();
//Declaring iteration counter and max and min number keeper
$max_iterations_count = 0;
$max_iterations_number = 0;
$min_iterations_count = PHP_INT_MAX;
$min_iterations_number = 0;
//showing chosen numbers
echo "Start number: " . $start . "_" . "Finish number: " . $finish . "<br>";
echo "results: " . "<br>";
//calculating values
for ($i = $start; $i <= $finish; $i++) {
    $number = $i;
    $max_number = $number;
    $iterated_number = 0;
    echo " number: " . $i . "<br>";
    while ($number != 1) {
        if ($number % 2 == 0) {
            $number = $number / 2;
        } else {
            $number = $number * 3 + 1;
        }

        if ($number > $max_number) {
            $max_number = $number;
        }
        echo $number . " "; // Output each iteration result separated by space
        $iterated_number++;
    }
    echo "<br>";
    $num[$i] = $iterated_number;
    echo "Iteration number: " . $iterated_number . "<br>";
    echo "Max number is " . $max_number . "<br>";
    echo "-------" . "<br>";
    if ($max_iterations_count < $iterated_number) {
        $max_iterations_count = $iterated_number;
        $max_iterations_number = $i;
    }
    if ($min_iterations_count > $iterated_number) {
        $min_iterations_count = $iterated_number;
        $min_iterations_number = $i;
    }
}
