<?php
$iterated_number = 0;
        $max_number = $number;
        echo "results: " . "<br>";
        while ($number != 1) {
           if ($number% 2 == 0) {
            $number = $number / 2;
           } else {
            $number = $number * 3 + 1;
           }  $iterated_number=$iterated_number + 1;
           if ($number > $max_number) {
            $max_number = $number;
           }
           echo $number . " "; // Output each iteration result separated by space
        } "<br>";