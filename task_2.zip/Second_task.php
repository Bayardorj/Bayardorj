<!DOCTYPE html>
<html>
<head>
    <title>3x + 1 Function Calculator</title>
</head>
<body>
    <h2>Calculate 3x + 1 Function</h2>
    <form method="post">
        <label for="main">Please enter number:</label>
        <input type="number" name="main" id="main" required><br><br>
        <input type="submit" value="Calculate">
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $number = $_POST["main"];
		echo "Number : " . $number . "<br>";
		include 'function_2.php';
        echo "Iteration number: ". $iterated_number . "<br>";
        echo "Max number is ". $max_number . "<br>";
        return 0;
    }
    ?>
</body>
</html>