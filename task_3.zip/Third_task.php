<!DOCTYPE html>
	<html>
	<head>
	    <title>3x + 1 Function Calculator</title>
	</head>
	<body>
	    <h2>Calculate 3x + 1 Function</h2>
	    <form method="post">
	        <label for="main">Please enter number:</label>
	        <input type="number" name="main" id="main" required><br><br>
	        <label for="start">Start Number(range):</label>
	        <input type="number" name="start" id="start" required><br><br>
	        
	        <label for="finish">Finish Number(range):</label>
	        <input type="number" name="finish" id="finish" required><br><br>
	        
	        <input type="submit" value="Calculate">
	    </form>
	    <?php
	    if ($_SERVER["REQUEST_METHOD"] == "POST") {
	        $start = $_POST["start"];
	        $finish = $_POST["finish"];
	        $number = $_POST["main"];
			echo "Number : " . $number . "<br>";
	        include 'function_3.php';

	        echo "Iterated number: ". $iterated_number . "<br>";
	        echo "Max number is ". $max_number . "<br>";
	        return 0;
	    }
	    ?>
	</body>
	</html>
