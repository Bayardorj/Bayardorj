
<?php
           $iterated_number = 0;
	        $max_number = $number;
	        echo "Start number: " . $start . "_" . "Finish number: " . $finish . "<br>";
	        echo "results: " . "<br>";
	        while ($number != 1) {
	           if ($number% 2 == 0) {
	            $number = $number / 2;
           } else {
	            $number = $number * 3 + 1;
	           } 
	           if ($start <= $number && $number <= $finish) {
	           $iterated_number=$iterated_number + 1;
	           if ($number > $max_number) {
	            $max_number = $number;
	           }
	           echo $number . " "; // Output each iteration result separated by space
	        }
	    }
	  
	      "<br>";