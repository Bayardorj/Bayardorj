<!DOCTYPE html>
<html>
<head>
    <title>3x + 1 Function Calculator</title>
</head>
<body>
    <h2>Calculate 3x + 1 Function</h2>
    <form method="post">
        <label for="start">Start number:</label>
        <input type="number" name="start" id="start" required><br><br>
        
        <label for="finish">Finish Number:</label>
        <input type="number" name="finish" id="finish" required><br><br>
        
        <input type="submit" value="Calculate">
    </form>
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $start = $_POST["start"];
    $finish = $_POST["finish"];
     include 'function_4.php';
    foreach ($num as $number => $iterated_number) {
        echo "$number: $iterated_number iterations<br>";
    }
    return 0;
}
?>